import bpy
import bmesh
import os
import math
from mathutils import Vector

# Bersihkan scene
bpy.ops.wm.read_factory_settings(use_empty=True)

tex_dir = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else "."

# 1. Buat Material PBR M_IndoAmbulance
mat = bpy.data.materials.new(name="M_IndoAmbulance")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

bsdf = nodes.new("ShaderNodeBsdfPrincipled")
bsdf.location = (200, 0)
output = nodes.new("ShaderNodeOutputMaterial")
output.location = (550, 0)
links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

maps = [
    ("IndoAmbulance_Albedo.png", "sRGB", "Base Color", (-300, 300)),
    ("IndoAmbulance_Metallic.png", "Non-Color", "Metallic", (-300, 50)),
    ("IndoAmbulance_Roughness.png", "Non-Color", "Roughness", (-300, -200)),
    ("IndoAmbulance_Emissive.png", "sRGB", "Emission Color", (-300, -450)),
]

for filename, colorspace, socket_name, loc in maps:
    path = os.path.join(tex_dir, filename)
    if os.path.exists(path):
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = bpy.data.images.load(path)
        tex.image.colorspace_settings.name = colorspace
        tex.location = loc
        links.new(tex.outputs["Color"], bsdf.inputs[socket_name])

norm_path = os.path.join(tex_dir, "IndoAmbulance_Normal.png")
if os.path.exists(norm_path):
    tex_norm = nodes.new("ShaderNodeTexImage")
    tex_norm.image = bpy.data.images.load(norm_path)
    tex_norm.image.colorspace_settings.name = "Non-Color"
    tex_norm.location = (-600, -700)
    norm_node = nodes.new("ShaderNodeNormalMap")
    norm_node.location = (-250, -700)
    links.new(tex_norm.outputs["Color"], norm_node.inputs["Color"])
    links.new(norm_node.outputs["Normal"], bsdf.inputs["Normal"])

def set_face_uv(bm, uv_layer, face, u0, v0, u1, v1):
    # v in Blender UV is 0 at bottom, 1 at top
    coords = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
    for i, loop in enumerate(face.loops):
        loop[uv_layer].uv = coords[i % 4]

# 2. Buat Body Utama Ambulans (Stylized Low-Poly Van)
mesh_body = bpy.data.meshes.new("Ambulance_Body_Mesh")
obj_body = bpy.data.objects.new("Ambulance_Body", mesh_body)
bpy.context.collection.objects.link(obj_body)
obj_body.data.materials.append(mat)

bm = bmesh.new()
uv_layer = bm.loops.layers.uv.new("UVMap")

# Dimensi Van (X: lebar 2.1m, Y: panjang 4.8m, Z: tinggi 2.2m)
# Rear Box (Y: -2.4 to 0.8, Z: 0.45 to 2.25)
v_rb = [
    bm.verts.new((-1.05, -2.4, 0.45)), bm.verts.new((1.05, -2.4, 0.45)),
    bm.verts.new((1.05, 0.8, 0.45)),   bm.verts.new((-1.05, 0.8, 0.45)),
    bm.verts.new((-1.00, -2.4, 2.25)), bm.verts.new((1.00, -2.4, 2.25)),
    bm.verts.new((1.00, 0.8, 2.25)),   bm.verts.new((-1.00, 0.8, 2.25)),
]
f_rear = bm.faces.new((v_rb[0], v_rb[1], v_rb[5], v_rb[4]))   # Rear double doors
f_right = bm.faces.new((v_rb[1], v_rb[2], v_rb[6], v_rb[5]))  # Right side
f_left = bm.faces.new((v_rb[3], v_rb[0], v_rb[4], v_rb[7]))   # Left side
f_top = bm.faces.new((v_rb[4], v_rb[5], v_rb[6], v_rb[7]))    # Roof
f_bot = bm.faces.new((v_rb[3], v_rb[2], v_rb[1], v_rb[0]))    # Floor

set_face_uv(bm, uv_layer, f_rear, 0.75, 0.75, 1.0, 1.0)
set_face_uv(bm, uv_layer, f_right, 0.0, 0.75, 0.5, 1.0)
set_face_uv(bm, uv_layer, f_left, 0.0, 0.75, 0.5, 1.0)
set_face_uv(bm, uv_layer, f_top, 0.26, 0.26, 0.60, 0.48)
set_face_uv(bm, uv_layer, f_bot, 0.76, 0.51, 0.99, 0.74)

# Cab & Hood (Y: 0.8 to 2.4)
v_cb = [
    bm.verts.new((-1.05, 0.8, 0.45)), bm.verts.new((1.05, 0.8, 0.45)),
    bm.verts.new((1.02, 2.4, 0.45)),  bm.verts.new((-1.02, 2.4, 0.45)),
    bm.verts.new((-1.00, 0.8, 1.30)), bm.verts.new((1.00, 0.8, 1.30)),
    bm.verts.new((0.98, 2.35, 1.15)), bm.verts.new((-0.98, 2.35, 1.15)),
    bm.verts.new((-0.96, 1.45, 2.20)),bm.verts.new((0.96, 1.45, 2.20)),
]
f_hood = bm.faces.new((v_cb[4], v_cb[5], v_cb[6], v_cb[7]))
f_wind = bm.faces.new((v_cb[7], v_cb[6], v_cb[9], v_cb[8]))
f_front = bm.faces.new((v_cb[3], v_cb[2], v_cb[6], v_cb[7]))
f_cab_r = bm.faces.new((v_cb[1], v_cb[2], v_cb[6], v_cb[5]))
f_cab_l = bm.faces.new((v_cb[3], v_cb[0], v_cb[4], v_cb[7]))
f_cab_top = bm.faces.new((v_cb[8], v_cb[9], v_rb[6], v_rb[7]))

set_face_uv(bm, uv_layer, f_hood, 0.50, 0.75, 0.75, 1.0)
set_face_uv(bm, uv_layer, f_wind, 0.01, 0.51, 0.24, 0.74)
set_face_uv(bm, uv_layer, f_front, 0.76, 0.51, 0.99, 0.74)
set_face_uv(bm, uv_layer, f_cab_r, 0.26, 0.26, 0.60, 0.48)
set_face_uv(bm, uv_layer, f_cab_l, 0.26, 0.26, 0.60, 0.48)
set_face_uv(bm, uv_layer, f_cab_top, 0.26, 0.26, 0.60, 0.48)

# Lightbar Roof (Blue-Red Light Bar at Y=1.25, Z=2.32)
def add_box(bm, uv_layer, min_v, max_v, u0, v0, u1, v1):
    x0, y0, z0 = min_v
    x1, y1, z1 = max_v
    vs = [
        bm.verts.new((x0, y0, z0)), bm.verts.new((x1, y0, z0)),
        bm.verts.new((x1, y1, z0)), bm.verts.new((x0, y1, z0)),
        bm.verts.new((x0, y0, z1)), bm.verts.new((x1, y0, z1)),
        bm.verts.new((x1, y1, z1)), bm.verts.new((x0, y1, z1)),
    ]
    faces = [
        bm.faces.new((vs[0], vs[1], vs[5], vs[4])),
        bm.faces.new((vs[1], vs[2], vs[6], vs[5])),
        bm.faces.new((vs[2], vs[3], vs[7], vs[6])),
        bm.faces.new((vs[3], vs[0], vs[4], vs[7])),
        bm.faces.new((vs[4], vs[5], vs[6], vs[7])),
        bm.faces.new((vs[3], vs[2], vs[1], vs[0])),
    ]
    for f in faces:
        set_face_uv(bm, uv_layer, f, u0, v0, u1, v1)

# Siren Left (Red) & Right (Blue)
add_box(bm, uv_layer, (-0.65, 1.15, 2.25), (-0.08, 1.38, 2.40), 0.26, 0.51, 0.36, 0.74)
add_box(bm, uv_layer, (0.08, 1.15, 2.25), (0.65, 1.38, 2.40), 0.39, 0.51, 0.49, 0.74)
add_box(bm, uv_layer, (-0.08, 1.15, 2.25), (0.08, 1.38, 2.40), 0.26, 0.26, 0.60, 0.48)

# Headlights & Taillights
add_box(bm, uv_layer, (-0.92, 2.36, 0.65), (-0.58, 2.43, 0.85), 0.01, 0.38, 0.11, 0.49)
add_box(bm, uv_layer, (0.58, 2.36, 0.65), (0.92, 2.43, 0.85), 0.01, 0.38, 0.11, 0.49)
add_box(bm, uv_layer, (-0.95, -2.43, 0.65), (-0.75, -2.38, 1.05), 0.13, 0.38, 0.24, 0.49)
add_box(bm, uv_layer, (0.75, -2.43, 0.65), (0.95, -2.38, 1.05), 0.13, 0.38, 0.24, 0.49)

bm.to_mesh(mesh_body)
bm.free()

# 3. Buat 4 Roda Terpisah (Separate Wheels untuk Roblox Rig/VehicleSeat)
wheel_positions = [
    ("Wheel_FL", (-0.98, 1.55, 0.42)),
    ("Wheel_FR", (0.98, 1.55, 0.42)),
    ("Wheel_RL", (-0.98, -1.45, 0.42)),
    ("Wheel_RR", (0.98, -1.45, 0.42)),
]

for w_name, loc in wheel_positions:
    w_mesh = bpy.data.meshes.new(w_name + "_Mesh")
    w_obj = bpy.data.objects.new(w_name, w_mesh)
    bpy.context.collection.objects.link(w_obj)
    w_obj.data.materials.append(mat)
    w_obj.location = loc

    bm_w = bmesh.new()
    uv_w = bm_w.loops.layers.uv.new("UVMap")
    bmesh.ops.create_cone(
        bm_w,
        cap_ends=True,
        cap_tris=False,
        segments=16,
        radius1=0.42,
        radius2=0.42,
        depth=0.28,
    )
    # Rotate cylinder so axle aligns along X-axis
    bmesh.ops.rotate(bm_w, verts=bm_w.verts, cent=(0, 0, 0), matrix=mathutils.Matrix.Rotation(math.radians(90), 3, 'Y'))
    for f in bm_w.faces:
        if len(f.verts) > 4:
            # Side cap (rim + tire) mapped to Tile (2,1)
            for loop in f.loops:
                co = loop.vert.co
                u = 0.625 + (co.y / 0.42) * 0.11
                v = 0.625 + (co.z / 0.42) * 0.11
                loop[uv_w].uv = (u, v)
        else:
            # Tire tread mapped to dark tire edge of Tile (2,1)
            set_face_uv(bm_w, uv_w, f, 0.51, 0.51, 0.54, 0.74)
    bm_w.to_mesh(w_mesh)
    bm_w.free()

# 4. Ekspor langsung ke FBX game-ready
fbx_out = os.path.join(tex_dir, "Indonesian_Ambulance_Roblox.fbx")
bpy.ops.export_scene.fbx(
    filepath=fbx_out,
    use_selection=False,
    apply_scale_options='FBX_SCALE_UNITS',
    axis_forward='-Z',
    axis_up='Y',
    mesh_smooth_type='FACE',
)
print("Berhasil membuat model 3D Ambulans & ekspor ke:", fbx_out)
