import os
import math
import bpy
import bmesh
from mathutils import Vector, Matrix


def get_script_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        if bpy.data.filepath:
            return os.path.dirname(bpy.data.filepath)
        return os.getcwd()


def load_pbr_image(tex_dir, filename, colorspace):
    path = os.path.join(tex_dir, filename)
    if os.path.exists(path):
        img = bpy.data.images.load(path, check_existing=True)
        img.colorspace_settings.name = colorspace
        return img
    return None


def create_pbr_material(tex_dir, mat_name="M_Angkot"):
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (220, 0)
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (550, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    img_alb = load_pbr_image(tex_dir, "Angkot_Albedo.png", "sRGB")
    if img_alb:
        tex_alb = nodes.new("ShaderNodeTexImage")
        tex_alb.image = img_alb
        tex_alb.location = (-320, 320)
        links.new(tex_alb.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.09, 0.62, 0.28, 1.0)

    img_met = load_pbr_image(tex_dir, "Angkot_Metallic.png", "Non-Color")
    if img_met:
        tex_met = nodes.new("ShaderNodeTexImage")
        tex_met.image = img_met
        tex_met.location = (-320, 60)
        links.new(tex_met.outputs["Color"], bsdf.inputs["Metallic"])

    img_rgh = load_pbr_image(tex_dir, "Angkot_Roughness.png", "Non-Color")
    if img_rgh:
        tex_rgh = nodes.new("ShaderNodeTexImage")
        tex_rgh.image = img_rgh
        tex_rgh.location = (-320, -200)
        links.new(tex_rgh.outputs["Color"], bsdf.inputs["Roughness"])

    img_nrm = load_pbr_image(tex_dir, "Angkot_Normal.png", "Non-Color")
    if img_nrm:
        tex_nrm = nodes.new("ShaderNodeTexImage")
        tex_nrm.image = img_nrm
        tex_nrm.location = (-580, -480)
        nrm_map = nodes.new("ShaderNodeNormalMap")
        nrm_map.location = (-240, -480)
        links.new(tex_nrm.outputs["Color"], nrm_map.inputs["Color"])
        links.new(nrm_map.outputs["Normal"], bsdf.inputs["Normal"])

    return mat


def assign_box_uv(bm, uv_layer, faces, u0, v0, u1, v1, axis="AUTO"):
    for f in faces:
        n = f.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
        if axis == "SIDE" or (axis == "AUTO" and ax >= ay and ax >= az):
            coords = [(l.vert.co.y, l.vert.co.z) for l in f.loops]
        elif axis == "FRONT" or (axis == "AUTO" and ay >= ax and ay >= az):
            coords = [(l.vert.co.x, l.vert.co.z) for l in f.loops]
        else:
            coords = [(l.vert.co.x, l.vert.co.y) for l in f.loops]

        min_u = min(c[0] for c in coords)
        max_u = max(c[0] for c in coords)
        min_v = min(c[1] for c in coords)
        max_v = max(c[1] for c in coords)
        du = max(max_u - min_u, 1e-5)
        dv = max(max_v - min_v, 1e-5)

        for loop, (cu, cv) in zip(f.loops, coords):
            nu = u0 + ((cu - min_u) / du) * (u1 - u0)
            nv = v0 + ((cv - min_v) / dv) * (v1 - v0)
            loop[uv_layer].uv = (nu, nv)


def add_beveled_box(bm, uv_layer, size, center, uv_rect, bevel_offset=0.03, bevel_segs=2, rot_euler=(0.0, 0.0, 0.0), axis="AUTO"):
    ret = bmesh.ops.create_cube(bm, size=1.0)
    verts = ret["verts"]
    sx, sy, sz = size
    for v in verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz

    edges = list({e for v in verts for e in v.link_edges})
    if bevel_offset > 0.0:
        res = bmesh.ops.bevel(
            bm,
            geom=edges,
            offset=bevel_offset,
            offset_type='OFFSET',
            segments=bevel_segs,
            profile=0.5,
            affect='EDGES',
            clamp_overlap=True,
        )
        part_verts = set(res["verts"])
    else:
        part_verts = set(verts)

    if any(abs(a) > 1e-5 for a in rot_euler):
        rot_mat = Matrix.Euler(rot_euler, 'XYZ').to_matrix()
        bmesh.ops.rotate(bm, verts=list(part_verts), cent=(0.0, 0.0, 0.0), matrix=rot_mat)

    cx, cy, cz = center
    for v in part_verts:
        v.co.x += cx
        v.co.y += cy
        v.co.z += cz

    part_faces = [f for f in bm.faces if all(v in part_verts for v in f.verts)]
    assign_box_uv(bm, uv_layer, part_faces, *uv_rect, axis=axis)
    return part_faces


def build_curved_angkot_shell(bm, uv_layer):
    # Profil minibus Angkot Indonesia (Suzuki Carry / Gran Max style)
    # Hidung depan pendek melengkung & atap membulat, bukan kotak kaku
    stations = [
        (-2.05, 0.84, 0.34, 1.82, 0.03),  # Belakang dengan bevel sudut
        (-1.92, 0.87, 0.32, 1.88, 0.05),  # Sudut belakang
        (-1.25, 0.88, 0.32, 1.90, 0.06),  # Poros roda belakang
        (0.25,  0.88, 0.32, 1.90, 0.06),  # Tengah (area pintu geser samping)
        (1.15,  0.88, 0.32, 1.90, 0.06),  # Pilar B (pintu depan)
        (1.58,  0.86, 0.32, 1.84, 0.05),  # Atas kaca depan miring
        (1.88,  0.84, 0.32, 1.12, 0.10),  # Pangkal kap mesin depan melengkung
        (2.04,  0.81, 0.34, 0.96, 0.12),  # Lengkung kap depan
        (2.12,  0.76, 0.38, 0.76, 0.06),  # Hidung/grille depan
    ]

    # 14 titik per ring agar bodi bawah, jendela, dan atap melengkung terpisah rapi
    rings = []
    for y, hw, z_bot, z_top, arch in stations:
        h = z_top - z_bot
        z_belt = z_bot + h * 0.46
        z_header = z_top - h * 0.12
        pts = [
            (-hw * 0.86, y, z_bot),                 # 0: Bawah kiri
            (0.0,        y, z_bot),                 # 1: Bawah tengah
            (hw * 0.86,  y, z_bot),                 # 2: Bawah kanan
            (hw,         y, z_bot + h * 0.14),      # 3: Skirt kanan
            (hw,         y, z_belt),                # 4: Beltline kanan
            (hw * 0.96,  y, z_header),              # 5: Atas jendela kanan
            (hw * 0.88,  y, z_top - h * 0.03),      # 6: Sudut atap kanan
            (hw * 0.52,  y, z_top + arch * 0.82),   # 7: Lengkung atap kanan
            (0.0,        y, z_top + arch),          # 8: Puncak atap
            (-hw * 0.52, y, z_top + arch * 0.82),   # 9: Lengkung atap kiri
            (-hw * 0.88, y, z_top - h * 0.03),      # 10: Sudut atap kiri
            (-hw * 0.96, y, z_header),              # 11: Atas jendela kiri
            (-hw,        y, z_belt),                # 12: Beltline kiri
            (-hw,        y, z_bot + h * 0.14),      # 13: Skirt kiri
        ]
        rings.append([bm.verts.new(p) for p in pts])

    n_pts = len(rings[0])
    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for i in range(n_pts):
            ni = (i + 1) % n_pts
            f = bm.faces.new((r0[i], r0[ni], r1[ni], r1[i]))

            if r_idx <= 4 and i in (3, 12):
                # Bodi samping bawah hijau + strip kuning-putih
                assign_box_uv(bm, uv_layer, [f], 0.01, 0.76, 0.49, 0.99, axis="SIDE")
            elif r_idx <= 4 and i in (4, 11):
                # Jendela samping angkot
                assign_box_uv(bm, uv_layer, [f], 0.02, 0.52, 0.23, 0.73, axis="SIDE")
            elif r_idx in (5, 6) and i in (5, 6, 7, 8, 9, 10):
                # Kaca depan miring (windshield)
                assign_box_uv(bm, uv_layer, [f], 0.02, 0.52, 0.23, 0.73, axis="FRONT")
            elif r_idx == 7 and i in (5, 6, 7, 8, 9, 10):
                # Kap mesin depan melengkung (hijau glossy)
                assign_box_uv(bm, uv_layer, [f], 0.30, 0.05, 0.95, 0.22, axis="TOP")
            else:
                # Bodi utama & atap hijau glossy
                assign_box_uv(bm, uv_layer, [f], 0.30, 0.05, 0.95, 0.22, axis="AUTO")

    # Tutup belakang (Tailgate angkot)
    f_rear = bm.faces.new(list(reversed(rings[0])))
    assign_box_uv(bm, uv_layer, [f_rear], 0.76, 0.76, 0.99, 0.88, axis="FRONT")

    # Tutup hidung depan (Grille)
    f_front = bm.faces.new(rings[-1])
    assign_box_uv(bm, uv_layer, [f_front], 0.77, 0.52, 0.98, 0.73, axis="FRONT")


def build_angkot_body(collection, mat):
    mesh = bpy.data.meshes.new("Body_Mesh")
    obj = bpy.data.objects.new("Body", mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    # 1. Cangkang utama angkot dengan kap pendek melengkung
    build_curved_angkot_shell(bm, uv_layer)

    # 2. Pintu Geser Samping (Side Sliding Door) di sisi kiri penumpang (-X) + rel pintu
    add_beveled_box(
        bm, uv_layer,
        size=(0.05, 0.96, 0.72),
        center=(-0.885, -0.15, 0.72),
        uv_rect=(0.51, 0.76, 0.74, 0.99),
        bevel_offset=0.015,
        bevel_segs=2,
        axis="SIDE",
    )
    # Kaca pintu geser samping
    add_beveled_box(
        bm, uv_layer,
        size=(0.04, 0.88, 0.54),
        center=(-0.875, -0.15, 1.38),
        uv_rect=(0.02, 0.52, 0.23, 0.73),
        bevel_offset=0.01,
        bevel_segs=2,
        axis="SIDE",
    )
    # Rel geser eksternal (Sliding track rail)
    add_beveled_box(
        bm, uv_layer,
        size=(0.03, 1.45, 0.04),
        center=(-0.895, -0.45, 1.05),
        uv_rect=(0.27, 0.52, 0.48, 0.73),
        bevel_offset=0.008,
        bevel_segs=1,
        axis="SIDE",
    )

    # 3. Papan trayek atap depan ("ANGKOT") & Kaca belakang
    add_beveled_box(bm, uv_layer, (0.92, 0.16, 0.22), (0.0, 1.42, 2.02), (0.76, 0.89, 0.99, 0.99), bevel_offset=0.02, bevel_segs=2, axis="FRONT")
    add_beveled_box(bm, uv_layer, (1.36, 0.05, 0.58), (0.0, -2.04, 1.38), (0.02, 0.52, 0.23, 0.73), bevel_offset=0.015, bevel_segs=2, axis="FRONT")

    # 4. Bumper depan & belakang ber-bevel
    add_beveled_box(bm, uv_layer, (1.72, 0.22, 0.24), (0.0, 2.10, 0.42), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.04, bevel_segs=3)
    add_beveled_box(bm, uv_layer, (1.76, 0.20, 0.22), (0.0, -2.06, 0.40), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.04, bevel_segs=3)

    # 5. Spion kiri & kanan (tangkai + rumah kaca ber-bevel)
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.16, 0.05, 0.04), (side * 0.92, 1.36, 1.24), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.01, bevel_segs=1)
        add_beveled_box(bm, uv_layer, (0.10, 0.14, 0.22), (side * 1.00, 1.34, 1.28), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.025, bevel_segs=2)

    # 6. Gagang pintu (2 pintu kabin depan, gagang pintu geser samping, gagang pintu belakang)
    handles = [
        (-0.89,  0.88, 0.96, (0.04, 0.14, 0.04)),
        (0.89,   0.88, 0.96, (0.04, 0.14, 0.04)),
        (-0.91,  0.22, 0.96, (0.04, 0.14, 0.04)),
        (0.00,  -2.06, 0.92, (0.16, 0.04, 0.04)),
    ]
    for hx, hy, hz, hdim in handles:
        add_beveled_box(bm, uv_layer, hdim, (hx, hy, hz), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.008, bevel_segs=1)

    # 7. Lampu utama depan, lampu sein oranye, dan lampu rem belakang
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.26, 0.10, 0.15), (side * 0.58, 2.08, 0.64), (0.02, 0.39, 0.10, 0.48), bevel_offset=0.02, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.11, 0.10, 0.15), (side * 0.74, 2.04, 0.64), (0.02, 0.27, 0.22, 0.36), bevel_offset=0.015, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.14, 0.09, 0.34), (side * 0.74, -2.05, 0.72), (0.14, 0.39, 0.23, 0.48), bevel_offset=0.02, bevel_segs=2)

    # 8. Fender lengkungan roda (4 roda)
    for side in (-1.0, 1.0):
        for wy in (1.28, -1.25):
            add_beveled_box(bm, uv_layer, (0.12, 0.76, 0.14), (side * 0.86, wy, 0.62), (0.30, 0.05, 0.95, 0.22), bevel_offset=0.025, bevel_segs=2)

    # Subdivide 1 level agar lengkungan halus dan segitiga berada dalam rentang 3.000 - 10.000
    bmesh.ops.subdivide_edges(bm, edges=list(bm.edges), cuts=1, use_grid_fill=True)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = True

    bm.to_mesh(mesh)
    bm.free()
    # Origin bodi tepat di tengah bawah antara roda
    obj.location = (0.0, 0.0, 0.0)
    return obj


def build_wheel_object(collection, mat, name, center_pos, radius=0.32, width=0.22, segments=24):
    mesh = bpy.data.meshes.new(name + "_Mesh")
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    half_w = width * 0.5
    r_outer = radius
    r_shoulder = radius * 0.93
    r_rim = radius * 0.62
    r_hub = radius * 0.22

    profile_rings = [
        (-half_w * 0.72, r_hub),
        (-half_w * 0.78, r_rim),
        (-half_w * 0.96, r_rim * 1.04),
        (-half_w,        r_shoulder),
        (-half_w * 0.85, r_outer),
        (half_w * 0.85,  r_outer),
        (half_w,         r_shoulder),
        (half_w * 0.96,  r_rim * 1.04),
        (half_w * 0.78,  r_rim),
        (half_w * 0.72,  r_hub),
    ]

    rings = []
    for x_pos, rad in profile_rings:
        ring_verts = []
        for s in range(segments):
            ang = (2.0 * math.pi * s) / segments
            y = math.cos(ang) * rad
            z = math.sin(ang) * rad
            ring_verts.append(bm.verts.new((x_pos, y, z)))
        rings.append(ring_verts)

    v_center_l = bm.verts.new((-half_w * 0.68, 0.0, 0.0))
    v_center_r = bm.verts.new((half_w * 0.68, 0.0, 0.0))

    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for s in range(segments):
            ns = (s + 1) % segments
            f = bm.faces.new((r0[s], r0[ns], r1[ns], r1[s]))
            f.smooth = True
            if r_idx in (0, 1, 7, 8):
                for loop in f.loops:
                    co = loop.vert.co
                    u = 0.625 + (co.y / r_outer) * 0.105
                    v = 0.625 + (co.z / r_outer) * 0.105
                    loop[uv_layer].uv = (u, v)
            else:
                coords = [(0.515, 0.515), (0.545, 0.515), (0.545, 0.735), (0.515, 0.735)]
                for i, loop in enumerate(f.loops):
                    loop[uv_layer].uv = coords[i % 4]

    for s in range(segments):
        ns = (s + 1) % segments
        f_l = bm.faces.new((rings[0][ns], rings[0][s], v_center_l))
        f_r = bm.faces.new((rings[-1][s], rings[-1][ns], v_center_r))
        for f in (f_l, f_r):
            f.smooth = True
            for loop in f.loops:
                co = loop.vert.co
                u = 0.625 + (co.y / r_outer) * 0.105
                v = 0.625 + (co.z / r_outer) * 0.105
                loop[uv_layer].uv = (u, v)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()

    # Origin roda di tengah poros masing-masing
    obj.location = center_pos
    return obj


def count_collection_triangles(collection):
    total = 0
    for obj in collection.objects:
        if obj.type == 'MESH':
            for poly in obj.data.polygons:
                total += len(poly.vertices) - 2
    return total


def main():
    asset_name = "angkot"
    tex_dir = get_script_dir()

    # Buat koleksi baru bernama 'angkot' tanpa menghapus objek lain di scene
    col = bpy.data.collections.get(asset_name)
    if col is None:
        col = bpy.data.collections.new(asset_name)
        bpy.context.scene.collection.children.link(col)
    else:
        for old_obj in list(col.objects):
            bpy.data.objects.remove(old_obj, do_unlink=True)

    mat = create_pbr_material(tex_dir, mat_name="M_Angkot")
    body_obj = build_angkot_body(col, mat)

    # 4 Roda terpisah (24 sisi) dengan origin tepat di tengah poros
    wheel_specs = [
        ("Wheel_FL", (-0.78,  1.28, 0.32)),
        ("Wheel_FR", (0.78,   1.28, 0.32)),
        ("Wheel_RL", (-0.78, -1.25, 0.32)),
        ("Wheel_RR", (0.78,  -1.25, 0.32)),
    ]
    wheel_objs = [
        build_wheel_object(col, mat, w_name, w_pos, radius=0.32, width=0.22, segments=24)
        for w_name, w_pos in wheel_specs
    ]

    all_meshes = [body_obj] + wheel_objs
    bpy.ops.object.select_all(action='DESELECT')
    for obj in all_meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = body_obj
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    print(f"[{asset_name}] Total segitiga mesh: {count_collection_triangles(col)} triangles")

    fbx_path = os.path.join(tex_dir, f"{asset_name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=fbx_path,
        use_selection=True,
        object_types={'MESH'},
        global_scale=1.0,
        apply_unit_scale=True,
        apply_scale_options='FBX_SCALE_ALL',
        use_space_transform=True,
        bake_space_transform=True,
        axis_forward='-Z',
        axis_up='Y',
        mesh_smooth_type='FACE',
        path_mode='COPY',
        embed_textures=True,
    )
    print(f"[{asset_name}] Berhasil diekspor ke: {fbx_path}")


if __name__ == "__main__":
    main()
