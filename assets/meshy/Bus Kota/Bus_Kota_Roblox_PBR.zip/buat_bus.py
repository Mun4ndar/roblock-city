import os
import math
import bpy
import bmesh
from mathutils import Vector, Matrix


def get_script_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        if bpy.data.filepath:
            return os.path.dirname(bpy.data.filepath)
        return os.getcwd()


def load_pbr_image(tex_dir, filename, colorspace):
    path = os.path.join(tex_dir, filename)
    if os.path.exists(path):
        img = bpy.data.images.load(path, check_existing=True)
        img.colorspace_settings.name = colorspace
        return img
    return None


def create_pbr_material(tex_dir, mat_name="M_BusKota"):
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (220, 0)
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (550, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    img_alb = load_pbr_image(tex_dir, "Bus_Albedo.png", "sRGB")
    if img_alb:
        tex_alb = nodes.new("ShaderNodeTexImage")
        tex_alb.image = img_alb
        tex_alb.location = (-320, 320)
        links.new(tex_alb.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.97, 0.75, 0.09, 1.0)

    img_met = load_pbr_image(tex_dir, "Bus_Metallic.png", "Non-Color")
    if img_met:
        tex_met = nodes.new("ShaderNodeTexImage")
        tex_met.image = img_met
        tex_met.location = (-320, 60)
        links.new(tex_met.outputs["Color"], bsdf.inputs["Metallic"])

    img_rgh = load_pbr_image(tex_dir, "Bus_Roughness.png", "Non-Color")
    if img_rgh:
        tex_rgh = nodes.new("ShaderNodeTexImage")
        tex_rgh.image = img_rgh
        tex_rgh.location = (-320, -200)
        links.new(tex_rgh.outputs["Color"], bsdf.inputs["Roughness"])

    img_nrm = load_pbr_image(tex_dir, "Bus_Normal.png", "Non-Color")
    if img_nrm:
        tex_nrm = nodes.new("ShaderNodeTexImage")
        tex_nrm.image = img_nrm
        tex_nrm.location = (-580, -480)
        nrm_map = nodes.new("ShaderNodeNormalMap")
        nrm_map.location = (-240, -480)
        links.new(tex_nrm.outputs["Color"], nrm_map.inputs["Color"])
        links.new(nrm_map.outputs["Normal"], bsdf.inputs["Normal"])

    return mat


def assign_box_uv(bm, uv_layer, faces, u0, v0, u1, v1, axis="AUTO"):
    for f in faces:
        n = f.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
        if axis == "SIDE" or (axis == "AUTO" and ax >= ay and ax >= az):
            coords = [(l.vert.co.y, l.vert.co.z) for l in f.loops]
        elif axis == "FRONT" or (axis == "AUTO" and ay >= ax and ay >= az):
            coords = [(l.vert.co.x, l.vert.co.z) for l in f.loops]
        else:
            coords = [(l.vert.co.x, l.vert.co.y) for l in f.loops]

        min_u = min(c[0] for c in coords)
        max_u = max(c[0] for c in coords)
        min_v = min(c[1] for c in coords)
        max_v = max(c[1] for c in coords)
        du = max(max_u - min_u, 1e-5)
        dv = max(max_v - min_v, 1e-5)

        for loop, (cu, cv) in zip(f.loops, coords):
            nu = u0 + ((cu - min_u) / du) * (u1 - u0)
            nv = v0 + ((cv - min_v) / dv) * (v1 - v0)
            loop[uv_layer].uv = (nu, nv)


def add_beveled_box(bm, uv_layer, size, center, uv_rect, bevel_offset=0.03, bevel_segs=2, rot_euler=(0.0, 0.0, 0.0), axis="AUTO"):
    ret = bmesh.ops.create_cube(bm, size=1.0)
    verts = ret["verts"]
    sx, sy, sz = size
    for v in verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz

    edges = list({e for v in verts for e in v.link_edges})
    if bevel_offset > 0.0:
        res = bmesh.ops.bevel(
            bm,
            geom=edges,
            offset=bevel_offset,
            offset_type='OFFSET',
            segments=bevel_segs,
            profile=0.5,
            affect='EDGES',
            clamp_overlap=True,
        )
        part_verts = set(res["verts"])
    else:
        part_verts = set(verts)

    if any(abs(a) > 1e-5 for a in rot_euler):
        rot_mat = Matrix.Euler(rot_euler, 'XYZ').to_matrix()
        bmesh.ops.rotate(bm, verts=list(part_verts), cent=(0.0, 0.0, 0.0), matrix=rot_mat)

    cx, cy, cz = center
    for v in part_verts:
        v.co.x += cx
        v.co.y += cy
        v.co.z += cz

    part_faces = [f for f in bm.faces if all(v in part_verts for v in f.verts)]
    assign_box_uv(bm, uv_layer, part_faces, *uv_rect, axis=axis)
    return part_faces


def build_curved_bus_shell(bm, uv_layer):
    # Profil bus kota Indonesia gaya kartun dengan bagian depan melengkung (aerodinamis, bukan kotak kaku)
    # Z=0.0 adalah dasar roda (ground), lantai bodi dimulai di Z=0.48
    stations = [
        (-4.50, 1.12, 0.52, 2.86, 0.04),  # Belakang bawah terangkat sedikit
        (-4.35, 1.18, 0.48, 2.94, 0.06),  # Sudut belakang ber-bevel
        (-3.20, 1.20, 0.48, 2.96, 0.07),  # Gandar roda belakang 2
        (-2.00, 1.20, 0.48, 2.96, 0.07),  # Gandar roda belakang 1
        (0.00,  1.20, 0.48, 2.96, 0.07),  # Tengah bodi
        (2.35,  1.20, 0.48, 2.96, 0.07),  # Gandar roda depan
        (3.45,  1.19, 0.48, 2.94, 0.06),  # Pilar depan kabin
        (4.15,  1.15, 0.48, 2.82, 0.05),  # Kaca depan miring melengkung
        (4.42,  1.10, 0.50, 1.56, 0.12),  # Kap/hidung depan melengkung ke bawah
        (4.52,  1.02, 0.54, 1.18, 0.08),  # Ujung moncong bumper depan
    ]

    # 16 titik per ring untuk memisahkan panel bodi bawah, jendela lebar, dan atap melengkung
    rings = []
    for y, hw, z_bot, z_top, arch in stations:
        h = z_top - z_bot
        z_belt = z_bot + h * 0.44   # Garis pinggang jendela (beltline)
        z_header = z_top - h * 0.14 # Garis atas jendela
        pts = [
            (-hw * 0.88, y, z_bot),                 # 0: Bawah kiri
            (0.0,        y, z_bot),                 # 1: Bawah tengah
            (hw * 0.88,  y, z_bot),                 # 2: Bawah kanan
            (hw,         y, z_bot + h * 0.12),      # 3: Skirt kanan bawah
            (hw,         y, z_belt),                # 4: Beltline kanan (atas bodi bawah)
            (hw * 0.97,  y, z_header),              # 5: Atas jendela kanan
            (hw * 0.90,  y, z_top - h * 0.03),      # 6: Sudut atap kanan
            (hw * 0.55,  y, z_top + arch * 0.80),   # 7: Lengkung atap kanan
            (0.0,        y, z_top + arch),          # 8: Puncak atap tengah
            (-hw * 0.55, y, z_top + arch * 0.80),   # 9: Lengkung atap kiri
            (-hw * 0.90, y, z_top - h * 0.03),      # 10: Sudut atap kiri
            (-hw * 0.97, y, z_header),              # 11: Atas jendela kiri
            (-hw,        y, z_belt),                # 12: Beltline kiri
            (-hw,        y, z_bot + h * 0.12),      # 13: Skirt kiri bawah
        ]
        rings.append([bm.verts.new(p) for p in pts])

    n_pts = len(rings[0])
    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for i in range(n_pts):
            ni = (i + 1) % n_pts
            f = bm.faces.new((r0[i], r0[ni], r1[ni], r1[i]))

            # Pemetaan UV rapi berdasarkan zona permukaan bus
            if r_idx <= 5 and i in (3, 12):
                # Bodi samping bawah (kuning dengan strip putih-oranye)
                assign_box_uv(bm, uv_layer, [f], 0.01, 0.76, 0.49, 0.99, axis="SIDE")
            elif r_idx <= 5 and i in (4, 11):
                # Jendela samping besar (large windows)
                assign_box_uv(bm, uv_layer, [f], 0.01, 0.51, 0.24, 0.74, axis="SIDE")
            elif r_idx in (6, 7) and i in (5, 6, 7, 8, 9, 10):
                # Kaca depan panorama lebar (large windshield)
                assign_box_uv(bm, uv_layer, [f], 0.02, 0.52, 0.23, 0.73, axis="FRONT")
            elif r_idx == 8 and i in (5, 6, 7, 8, 9, 10):
                # Kap / hidung depan melengkung (kuning glossy)
                assign_box_uv(bm, uv_layer, [f], 0.30, 0.05, 0.95, 0.22, axis="TOP")
            else:
                # Bodi utama & atap kuning glossy
                assign_box_uv(bm, uv_layer, [f], 0.30, 0.05, 0.95, 0.22, axis="AUTO")

    # Tutup belakang (Kaca belakang + kisi mesin bawah)
    f_rear = bm.faces.new(list(reversed(rings[0])))
    assign_box_uv(bm, uv_layer, [f_rear], 0.76, 0.76, 0.99, 0.87, axis="FRONT")

    # Tutup hidung depan (Grille)
    f_front = bm.faces.new(rings[-1])
    assign_box_uv(bm, uv_layer, [f_front], 0.77, 0.52, 0.98, 0.73, axis="FRONT")


def build_bus_body(collection, mat):
    mesh = bpy.data.meshes.new("Body_Mesh")
    obj = bpy.data.objects.new("Body", mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    # 1. Cangkang utama bus kota melengkung dengan jendela lebar
    build_curved_bus_shell(bm, uv_layer)

    # 2. Pintu penumpang lipat (depan & tengah di sisi kiri/penumpang Indonesia)
    for dy in (2.85, -0.55):
        add_beveled_box(
            bm, uv_layer,
            size=(0.06, 0.96, 2.02),
            center=(-1.20, dy, 1.54),
            uv_rect=(0.51, 0.76, 0.74, 0.99),
            bevel_offset=0.015,
            bevel_segs=2,
            axis="SIDE",
        )

    # Kaca belakang besar & papan trayek depan "BUS KOTA"
    add_beveled_box(bm, uv_layer, (1.86, 0.06, 0.88), (0.0, -4.49, 2.15), (0.02, 0.52, 0.23, 0.73), bevel_offset=0.015, bevel_segs=2, axis="FRONT")
    add_beveled_box(bm, uv_layer, (1.55, 0.08, 0.26), (0.0, 4.12, 2.66), (0.76, 0.88, 0.99, 0.99), bevel_offset=0.015, bevel_segs=2, axis="FRONT")

    # 3. Unit AC Atap (2 Roof AC Pods)
    for ay in (1.20, -1.65):
        add_beveled_box(bm, uv_layer, (1.38, 1.65, 0.24), (0.0, ay, 3.08), (0.27, 0.52, 0.48, 0.73), bevel_offset=0.05, bevel_segs=3, axis="TOP")

    # 4. Bumper depan & belakang ber-bevel
    add_beveled_box(bm, uv_layer, (2.28, 0.30, 0.36), (0.0, 4.48, 0.56), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.05, bevel_segs=3)
    add_beveled_box(bm, uv_layer, (2.26, 0.28, 0.34), (0.0, -4.46, 0.56), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.05, bevel_segs=3)

    # 5. Spion tanduk khas bus kota Indonesia kiri & kanan
    for side in (-1.0, 1.0):
        # Lengan spion atas melengkung keluar
        add_beveled_box(bm, uv_layer, (0.28, 0.06, 0.06), (side * 1.24, 3.85, 2.38), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.015, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.06, 0.06, 0.34), (side * 1.36, 3.88, 2.22), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.015, bevel_segs=2)
        # Rumah kaca spion ber-bevel
        add_beveled_box(bm, uv_layer, (0.12, 0.16, 0.42), (side * 1.36, 3.90, 2.02), (0.30, 0.05, 0.95, 0.22), bevel_offset=0.03, bevel_segs=3)

    # 6. Gagang pintu pengemudi & pintu penumpang
    handles = [
        (1.20,  3.15, 1.28),
        (-1.21, 2.85, 1.25),
        (-1.21, -0.55, 1.25),
    ]
    for hx, hy, hz in handles:
        add_beveled_box(bm, uv_layer, (0.05, 0.18, 0.05), (hx, hy, hz), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.01, bevel_segs=1)

    # 7. Lampu depan (Headlights + Sein Oranye) & Lampu belakang (Taillights)
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.34, 0.12, 0.18), (side * 0.78, 4.48, 0.84), (0.02, 0.39, 0.10, 0.48), bevel_offset=0.025, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.14, 0.12, 0.18), (side * 0.98, 4.42, 0.84), (0.02, 0.27, 0.22, 0.36), bevel_offset=0.02, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.20, 0.10, 0.46), (side * 0.96, -4.48, 0.92), (0.14, 0.39, 0.23, 0.48), bevel_offset=0.025, bevel_segs=2)

    # 8. Fender lengkungan roda (6 roda: depan, tengah, belakang)
    for side in (-1.0, 1.0):
        for wy in (2.35, -2.00, -3.20):
            add_beveled_box(bm, uv_layer, (0.16, 1.08, 0.20), (side * 1.18, wy, 0.94), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.04, bevel_segs=2)

    # Subdivide 1 level agar permukaan lengkung halus dan jumlah segitiga dalam rentang 3.000 - 10.000
    bmesh.ops.subdivide_edges(bm, edges=list(bm.edges), cuts=1, use_grid_fill=True)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = True

    bm.to_mesh(mesh)
    bm.free()
    # Origin bodi di tengah bawah antara roda
    obj.location = (0.0, 0.0, 0.0)
    return obj


def build_wheel_object(collection, mat, name, center_pos, radius=0.48, width=0.30, segments=24):
    mesh = bpy.data.meshes.new(name + "_Mesh")
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    half_w = width * 0.5
    r_outer = radius
    r_shoulder = radius * 0.93
    r_rim = radius * 0.60
    r_hub = radius * 0.22

    profile_rings = [
        (-half_w * 0.72, r_hub),
        (-half_w * 0.78, r_rim),
        (-half_w * 0.96, r_rim * 1.04),
        (-half_w,        r_shoulder),
        (-half_w * 0.85, r_outer),
        (half_w * 0.85,  r_outer),
        (half_w,         r_shoulder),
        (half_w * 0.96,  r_rim * 1.04),
        (half_w * 0.78,  r_rim),
        (half_w * 0.72,  r_hub),
    ]

    rings = []
    for x_pos, rad in profile_rings:
        ring_verts = []
        for s in range(segments):
            ang = (2.0 * math.pi * s) / segments
            y = math.cos(ang) * rad
            z = math.sin(ang) * rad
            ring_verts.append(bm.verts.new((x_pos, y, z)))
        rings.append(ring_verts)

    v_center_l = bm.verts.new((-half_w * 0.68, 0.0, 0.0))
    v_center_r = bm.verts.new((half_w * 0.68, 0.0, 0.0))

    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for s in range(segments):
            ns = (s + 1) % segments
            f = bm.faces.new((r0[s], r0[ns], r1[ns], r1[s]))
            f.smooth = True
            if r_idx in (0, 1, 7, 8):
                for loop in f.loops:
                    co = loop.vert.co
                    u = 0.625 + (co.y / r_outer) * 0.105
                    v = 0.625 + (co.z / r_outer) * 0.105
                    loop[uv_layer].uv = (u, v)
            else:
                coords = [(0.515, 0.515), (0.545, 0.515), (0.545, 0.735), (0.515, 0.735)]
                for i, loop in enumerate(f.loops):
                    loop[uv_layer].uv = coords[i % 4]

    for s in range(segments):
        ns = (s + 1) % segments
        f_l = bm.faces.new((rings[0][ns], rings[0][s], v_center_l))
        f_r = bm.faces.new((rings[-1][s], rings[-1][ns], v_center_r))
        for f in (f_l, f_r):
            f.smooth = True
            for loop in f.loops:
                co = loop.vert.co
                u = 0.625 + (co.y / r_outer) * 0.105
                v = 0.625 + (co.z / r_outer) * 0.105
                loop[uv_layer].uv = (u, v)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()

    # Origin roda di tengah poros masing-masing
    obj.location = center_pos
    return obj


def count_collection_triangles(collection):
    total = 0
    for obj in collection.objects:
        if obj.type == 'MESH':
            for poly in obj.data.polygons:
                total += len(poly.vertices) - 2
    return total


def main():
    asset_name = "bus"
    tex_dir = get_script_dir()

    # Buat koleksi baru bernama 'bus' tanpa menghapus objek lain di scene
    col = bpy.data.collections.get(asset_name)
    if col is None:
        col = bpy.data.collections.new(asset_name)
        bpy.context.scene.collection.children.link(col)
    else:
        for old_obj in list(col.objects):
            bpy.data.objects.remove(old_obj, do_unlink=True)

    mat = create_pbr_material(tex_dir, mat_name="M_BusKota")
    body_obj = build_bus_body(col, mat)

    # 6 Roda terpisah (24 sisi) dengan origin tepat di tengah poros
    wheel_specs = [
        ("Wheel_FL", (-1.08,  2.35, 0.48)),
        ("Wheel_FR", (1.08,   2.35, 0.48)),
        ("Wheel_ML", (-1.08, -2.00, 0.48)),
        ("Wheel_MR", (1.08,  -2.00, 0.48)),
        ("Wheel_RL", (-1.08, -3.20, 0.48)),
        ("Wheel_RR", (1.08,  -3.20, 0.48)),
    ]
    wheel_objs = [
        build_wheel_object(col, mat, w_name, w_pos, radius=0.48, width=0.30, segments=24)
        for w_name, w_pos in wheel_specs
    ]

    all_meshes = [body_obj] + wheel_objs
    bpy.ops.object.select_all(action='DESELECT')
    for obj in all_meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = body_obj
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    print(f"[{asset_name}] Total segitiga mesh: {count_collection_triangles(col)} triangles")

    fbx_path = os.path.join(tex_dir, f"{asset_name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=fbx_path,
        use_selection=True,
        object_types={'MESH'},
        global_scale=1.0,
        apply_unit_scale=True,
        apply_scale_options='FBX_SCALE_ALL',
        use_space_transform=True,
        bake_space_transform=True,
        axis_forward='-Z',
        axis_up='Y',
        mesh_smooth_type='FACE',
        path_mode='COPY',
        embed_textures=True,
    )
    print(f"[{asset_name}] Berhasil diekspor ke: {fbx_path}")


if __name__ == "__main__":
    main()
