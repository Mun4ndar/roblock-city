import os
import math
import bpy
import bmesh
from mathutils import Vector, Matrix


def get_script_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        if bpy.data.filepath:
            return os.path.dirname(bpy.data.filepath)
        return os.getcwd()


def load_pbr_image(tex_dir, filename, colorspace):
    path = os.path.join(tex_dir, filename)
    if os.path.exists(path):
        img = bpy.data.images.load(path, check_existing=True)
        img.colorspace_settings.name = colorspace
        return img
    return None


def create_pbr_material(tex_dir, mat_name="M_Damkar"):
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (220, 0)
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (550, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    img_alb = load_pbr_image(tex_dir, "Damkar_Albedo.png", "sRGB")
    if img_alb:
        tex_alb = nodes.new("ShaderNodeTexImage")
        tex_alb.image = img_alb
        tex_alb.location = (-320, 320)
        links.new(tex_alb.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.85, 0.12, 0.15, 1.0)

    img_met = load_pbr_image(tex_dir, "Damkar_Metallic.png", "Non-Color")
    if img_met:
        tex_met = nodes.new("ShaderNodeTexImage")
        tex_met.image = img_met
        tex_met.location = (-320, 60)
        links.new(tex_met.outputs["Color"], bsdf.inputs["Metallic"])

    img_rgh = load_pbr_image(tex_dir, "Damkar_Roughness.png", "Non-Color")
    if img_rgh:
        tex_rgh = nodes.new("ShaderNodeTexImage")
        tex_rgh.image = img_rgh
        tex_rgh.location = (-320, -200)
        links.new(tex_rgh.outputs["Color"], bsdf.inputs["Roughness"])

    img_nrm = load_pbr_image(tex_dir, "Damkar_Normal.png", "Non-Color")
    if img_nrm:
        tex_nrm = nodes.new("ShaderNodeTexImage")
        tex_nrm.image = img_nrm
        tex_nrm.location = (-580, -480)
        nrm_map = nodes.new("ShaderNodeNormalMap")
        nrm_map.location = (-240, -480)
        links.new(tex_nrm.outputs["Color"], nrm_map.inputs["Color"])
        links.new(nrm_map.outputs["Normal"], bsdf.inputs["Normal"])

    return mat


def assign_box_uv(bm, uv_layer, faces, u0, v0, u1, v1, axis="AUTO"):
    for f in faces:
        n = f.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
        if axis == "SIDE" or (axis == "AUTO" and ax >= ay and ax >= az):
            coords = [(l.vert.co.y, l.vert.co.z) for l in f.loops]
        elif axis == "FRONT" or (axis == "AUTO" and ay >= ax and ay >= az):
            coords = [(l.vert.co.x, l.vert.co.z) for l in f.loops]
        else:
            coords = [(l.vert.co.x, l.vert.co.y) for l in f.loops]

        min_u = min(c[0] for c in coords)
        max_u = max(c[0] for c in coords)
        min_v = min(c[1] for c in coords)
        max_v = max(c[1] for c in coords)
        du = max(max_u - min_u, 1e-5)
        dv = max(max_v - min_v, 1e-5)

        for loop, (cu, cv) in zip(f.loops, coords):
            nu = u0 + ((cu - min_u) / du) * (u1 - u0)
            nv = v0 + ((cv - min_v) / dv) * (v1 - v0)
            loop[uv_layer].uv = (nu, nv)


def add_beveled_box(bm, uv_layer, size, center, uv_rect, bevel_offset=0.03, bevel_segs=2, rot_euler=(0.0, 0.0, 0.0), axis="AUTO"):
    ret = bmesh.ops.create_cube(bm, size=1.0)
    verts = ret["verts"]
    sx, sy, sz = size
    for v in verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz

    edges = list({e for v in verts for e in v.link_edges})
    if bevel_offset > 0.0:
        res = bmesh.ops.bevel(
            bm,
            geom=edges,
            offset=bevel_offset,
            offset_type='OFFSET',
            segments=bevel_segs,
            profile=0.5,
            affect='EDGES',
            clamp_overlap=True,
        )
        part_verts = set(res["verts"])
    else:
        part_verts = set(verts)

    if any(abs(a) > 1e-5 for a in rot_euler):
        rot_mat = Matrix.Euler(rot_euler, 'XYZ').to_matrix()
        bmesh.ops.rotate(bm, verts=list(part_verts), cent=(0.0, 0.0, 0.0), matrix=rot_mat)

    cx, cy, cz = center
    for v in part_verts:
        v.co.x += cx
        v.co.y += cy
        v.co.z += cz

    part_faces = [f for f in bm.faces if all(v in part_verts for v in f.verts)]
    assign_box_uv(bm, uv_layer, part_faces, *uv_rect, axis=axis)
    return part_faces


def build_curved_cab(bm, uv_layer, y_rear, y_front, hw=1.12, z_bot=0.48, z_top=2.45):
    # Profil kabin truk pemadam Indonesia dengan hidung & kap melengkung
    length = y_front - y_rear
    stations = [
        (y_rear,                  hw,        z_bot,        z_top,        0.02),
        (y_rear + length * 0.52,  hw,        z_bot,        z_top,        0.04),
        (y_rear + length * 0.72,  hw * 0.98, z_bot,        z_top - 0.14, 0.06),
        (y_rear + length * 0.84,  hw * 0.96, z_bot,        z_bot + 1.02, 0.12),
        (y_rear + length * 0.95,  hw * 0.93, z_bot + 0.02, z_bot + 0.90, 0.14),
        (y_front,                 hw * 0.89, z_bot + 0.05, z_bot + 0.72, 0.08),
    ]
    rings = []
    for y, w, zb, zt, arch in stations:
        h = zt - zb
        pts = [
            (-w * 0.86, y, zb),
            (0.0,       y, zb),
            (w * 0.86,  y, zb),
            (w,         y, zb + h * 0.16),
            (w,         y, zb + h * 0.62),
            (w * 0.94,  y, zt - h * 0.08),
            (w * 0.70,  y, zt + arch * 0.75),
            (0.0,       y, zt + arch),
            (-w * 0.70, y, zt + arch * 0.75),
            (-w * 0.94, y, zt - h * 0.08),
            (-w,        y, zb + h * 0.62),
            (-w,        y, zb + h * 0.16),
        ]
        rings.append([bm.verts.new(p) for p in pts])

    n_pts = len(rings[0])
    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for i in range(n_pts):
            ni = (i + 1) % n_pts
            f = bm.faces.new((r0[i], r0[ni], r1[ni], r1[i]))
            if r_idx in (1, 2) and i in (5, 6, 7, 8):
                # Kaca depan
                assign_box_uv(bm, uv_layer, [f], 0.02, 0.52, 0.23, 0.73, axis="FRONT")
            elif r_idx in (0, 1) and i in (4, 9):
                # Kaca pintu kabin
                assign_box_uv(bm, uv_layer, [f], 0.02, 0.52, 0.23, 0.73, axis="SIDE")
            elif r_idx in (3, 4) and i in (5, 6, 7, 8):
                # Kap mesin melengkung (merah mengilap)
                assign_box_uv(bm, uv_layer, [f], 0.05, 0.02, 0.95, 0.23, axis="TOP")
            else:
                # Bodi merah glossy
                assign_box_uv(bm, uv_layer, [f], 0.05, 0.02, 0.95, 0.23, axis="AUTO")

    f_back = bm.faces.new(list(reversed(rings[0])))
    assign_box_uv(bm, uv_layer, [f_back], 0.05, 0.02, 0.95, 0.23, axis="FRONT")
    f_nose = bm.faces.new(rings[-1])
    assign_box_uv(bm, uv_layer, [f_nose], 0.77, 0.52, 0.98, 0.73, axis="FRONT")


def build_ladder_assembly(bm, uv_layer, length, width, z_base, y_center, tilt_deg=0.0):
    # Tangga aluminium lengkap dengan 2 rel samping ber-bevel dan anak tangga
    rot = (math.radians(tilt_deg), 0.0, 0.0)
    hw = width * 0.5
    # Rel kiri & kanan
    for side in (-1.0, 1.0):
        add_beveled_box(
            bm, uv_layer,
            size=(0.06, length, 0.12),
            center=(side * hw, y_center, z_base),
            uv_rect=(0.27, 0.27, 0.48, 0.48),
            bevel_offset=0.015,
            bevel_segs=2,
            rot_euler=rot,
        )
    # Anak tangga (rungs)
    num_rungs = int(length / 0.34)
    for idx in range(num_rungs):
        local_y = -length * 0.46 + idx * (length * 0.92 / max(num_rungs - 1, 1))
        dy = math.cos(math.radians(tilt_deg)) * local_y
        dz = math.sin(math.radians(tilt_deg)) * local_y
        add_beveled_box(
            bm, uv_layer,
            size=(width - 0.04, 0.04, 0.04),
            center=(0.0, y_center + dy, z_base + dz),
            uv_rect=(0.27, 0.27, 0.48, 0.48),
            bevel_offset=0.008,
            bevel_segs=1,
            rot_euler=rot,
        )


def build_wheel_object(collection, mat, name, center_pos, radius=0.48, width=0.30, segments=24):
    mesh = bpy.data.meshes.new(name + "_Mesh")
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    half_w = width * 0.5
    r_outer = radius
    r_shoulder = radius * 0.93
    r_rim = radius * 0.60
    r_hub = radius * 0.22

    profile_rings = [
        (-half_w * 0.72, r_hub),
        (-half_w * 0.78, r_rim),
        (-half_w * 0.96, r_rim * 1.04),
        (-half_w,        r_shoulder),
        (-half_w * 0.85, r_outer),
        (half_w * 0.85,  r_outer),
        (half_w,         r_shoulder),
        (half_w * 0.96,  r_rim * 1.04),
        (half_w * 0.78,  r_rim),
        (half_w * 0.72,  r_hub),
    ]

    rings = []
    for x_pos, rad in profile_rings:
        ring_verts = []
        for s in range(segments):
            ang = (2.0 * math.pi * s) / segments
            y = math.cos(ang) * rad
            z = math.sin(ang) * rad
            ring_verts.append(bm.verts.new((x_pos, y, z)))
        rings.append(ring_verts)

    v_center_l = bm.verts.new((-half_w * 0.68, 0.0, 0.0))
    v_center_r = bm.verts.new((half_w * 0.68, 0.0, 0.0))

    for r_idx in range(len(rings) - 1):
        r0 = rings[r_idx]
        r1 = rings[r_idx + 1]
        for s in range(segments):
            ns = (s + 1) % segments
            f = bm.faces.new((r0[s], r0[ns], r1[ns], r1[s]))
            f.smooth = True
            if r_idx in (0, 1, 7, 8):
                for loop in f.loops:
                    co = loop.vert.co
                    u = 0.625 + (co.y / r_outer) * 0.105
                    v = 0.625 + (co.z / r_outer) * 0.105
                    loop[uv_layer].uv = (u, v)
            else:
                coords = [(0.515, 0.515), (0.545, 0.515), (0.545, 0.735), (0.515, 0.735)]
                for i, loop in enumerate(f.loops):
                    loop[uv_layer].uv = coords[i % 4]

    for s in range(segments):
        ns = (s + 1) % segments
        f_l = bm.faces.new((rings[0][ns], rings[0][s], v_center_l))
        f_r = bm.faces.new((rings[-1][s], rings[-1][ns], v_center_r))
        for f in (f_l, f_r):
            f.smooth = True
            for loop in f.loops:
                co = loop.vert.co
                u = 0.625 + (co.y / r_outer) * 0.105
                v = 0.625 + (co.z / r_outer) * 0.105
                loop[uv_layer].uv = (u, v)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()

    obj.location = center_pos
    return obj


def count_collection_triangles(collection):
    total = 0
    for obj in collection.objects:
        if obj.type == 'MESH':
            for poly in obj.data.polygons:
                total += len(poly.vertices) - 2
    return total


def build_damkar_body(collection, mat):
    mesh = bpy.data.meshes.new("Body_Mesh")
    obj = bpy.data.objects.new("Body", mesh)
    collection.objects.link(obj)
    obj.data.materials.append(mat)

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    # 1. Kabin depan melengkung (Y: 0.75 to 3.15)
    build_curved_cab(bm, uv_layer, y_rear=0.75, y_front=3.15, hw=1.12, z_bot=0.48, z_top=2.45)

    # 2. Kompartemen boks peralatan belakang (Y: -3.15 to 0.68)
    add_beveled_box(bm, uv_layer, (2.26, 3.82, 1.94), (0.0, -1.24, 1.46), (0.01, 0.76, 0.49, 0.99), bevel_offset=0.06, bevel_segs=3, axis="SIDE")

    # Panel chevron belakang
    add_beveled_box(bm, uv_layer, (2.16, 0.06, 1.82), (0.0, -3.14, 1.46), (0.76, 0.76, 0.99, 0.99), bevel_offset=0.01, bevel_segs=1, axis="FRONT")

    # 3. Pintu rolling shutter loker peralatan (Equipment Lockers) di sisi kiri & kanan
    for side in (-1.0, 1.0):
        for ly in (-0.15, -1.35, -2.45):
            add_beveled_box(bm, uv_layer, (0.06, 0.95, 1.28), (side * 1.13, ly, 1.38), (0.51, 0.76, 0.74, 0.99), bevel_offset=0.01, bevel_segs=2, axis="SIDE")

    # 4. Sasis & Bumper depan/belakang ber-bevel
    add_beveled_box(bm, uv_layer, (1.85, 6.10, 0.24), (0.0, 0.0, 0.46), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.03, bevel_segs=2)
    add_beveled_box(bm, uv_layer, (2.32, 0.28, 0.34), (0.0, 3.14, 0.52), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.05, bevel_segs=3)
    add_beveled_box(bm, uv_layer, (2.32, 0.24, 0.28), (0.0, -3.18, 0.50), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.04, bevel_segs=3)

    # 5. Spion besar khas truk damkar kiri & kanan
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.22, 0.05, 0.05), (side * 1.18, 2.05, 1.95), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.01, bevel_segs=1)
        add_beveled_box(bm, uv_layer, (0.22, 0.05, 0.05), (side * 1.18, 2.05, 1.48), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.01, bevel_segs=1)
        add_beveled_box(bm, uv_layer, (0.10, 0.16, 0.52), (side * 1.28, 2.04, 1.72), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.025, bevel_segs=2)

    # 6. Gagang pintu kabin & loker
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.05, 0.18, 0.05), (side * 1.13, 1.22, 1.35), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.01, bevel_segs=1)

    # 7. Lampu utama, lampu sein, lampu rem, dan sirine atap
    for side in (-1.0, 1.0):
        add_beveled_box(bm, uv_layer, (0.32, 0.12, 0.18), (side * 0.78, 3.12, 0.78), (0.02, 0.39, 0.10, 0.48), bevel_offset=0.02, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.14, 0.12, 0.18), (side * 0.98, 3.08, 0.78), (0.02, 0.27, 0.22, 0.36), bevel_offset=0.02, bevel_segs=2)
        add_beveled_box(bm, uv_layer, (0.18, 0.10, 0.44), (side * 0.96, -3.16, 0.88), (0.14, 0.39, 0.23, 0.48), bevel_offset=0.02, bevel_segs=2)

    # Roof Lightbar
    add_beveled_box(bm, uv_layer, (0.62, 0.24, 0.15), (-0.42, 1.75, 2.52), (0.27, 0.52, 0.35, 0.73), bevel_offset=0.03, bevel_segs=3)
    add_beveled_box(bm, uv_layer, (0.20, 0.25, 0.16), (0.00,  1.75, 2.52), (0.52, 0.27, 0.98, 0.48), bevel_offset=0.02, bevel_segs=2)
    add_beveled_box(bm, uv_layer, (0.62, 0.24, 0.15), (0.42,  1.75, 2.52), (0.40, 0.52, 0.48, 0.73), bevel_offset=0.03, bevel_segs=3)

    # 8. Tangga atap (Rooftop Ladder) + braket dudukan
    for ly in (-0.2, -2.2):
        add_beveled_box(bm, uv_layer, (0.72, 0.14, 0.14), (0.45, ly, 2.48), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.02, bevel_segs=2)
    build_ladder_assembly(bm, uv_layer, length=3.45, width=0.58, z_base=2.58, y_center=-1.22, tilt_deg=0.0)

    # Selang gulung (Hose reel) di atas boks sisi kiri
    add_beveled_box(bm, uv_layer, (0.54, 0.78, 0.26), (-0.52, -1.20, 2.52), (0.52, 0.27, 0.98, 0.48), bevel_offset=0.04, bevel_segs=2)

    # Fender lengkungan roda (4 roda)
    for side in (-1.0, 1.0):
        for wy in (1.85, -1.85):
            add_beveled_box(bm, uv_layer, (0.18, 1.12, 0.22), (side * 1.10, wy, 0.92), (0.77, 0.52, 0.98, 0.73), bevel_offset=0.04, bevel_segs=2)

    bmesh.ops.subdivide_edges(bm, edges=list(bm.edges), cuts=1, use_grid_fill=True)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = True

    bm.to_mesh(mesh)
    bm.free()
    obj.location = (0.0, 0.0, 0.0)
    return obj


def main():
    asset_name = "damkar"
    tex_dir = get_script_dir()

    col = bpy.data.collections.get(asset_name)
    if col is None:
        col = bpy.data.collections.new(asset_name)
        bpy.context.scene.collection.children.link(col)
    else:
        for old_obj in list(col.objects):
            bpy.data.objects.remove(old_obj, do_unlink=True)

    mat = create_pbr_material(tex_dir, mat_name="M_Damkar")
    body_obj = build_damkar_body(col, mat)

    wheel_specs = [
        ("Wheel_FL", (-1.02,  1.85, 0.48)),
        ("Wheel_FR", (1.02,   1.85, 0.48)),
        ("Wheel_RL", (-1.02, -1.85, 0.48)),
        ("Wheel_RR", (1.02,  -1.85, 0.48)),
    ]
    wheel_objs = [
        build_wheel_object(col, mat, w_name, w_pos, radius=0.48, width=0.32, segments=24)
        for w_name, w_pos in wheel_specs
    ]

    all_meshes = [body_obj] + wheel_objs
    bpy.ops.object.select_all(action='DESELECT')
    for obj in all_meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = body_obj
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    print(f"[{asset_name}] Total segitiga mesh: {count_collection_triangles(col)} triangles")

    fbx_path = os.path.join(tex_dir, f"{asset_name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=fbx_path,
        use_selection=True,
        object_types={'MESH'},
        global_scale=1.0,
        apply_unit_scale=True,
        apply_scale_options='FBX_SCALE_ALL',
        use_space_transform=True,
        bake_space_transform=True,
        axis_forward='-Z',
        axis_up='Y',
        mesh_smooth_type='FACE',
        path_mode='COPY',
        embed_textures=True,
    )
    print(f"[{asset_name}] Berhasil diekspor ke: {fbx_path}")


if __name__ == "__main__":
    main()
